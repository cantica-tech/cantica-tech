# Artifact Layout Reference

The canonical, illustrative tree for a deployed `.criterion/` under
the uniform artifact-type layout (`Rules-of-Rules.md` §15, `INVARIANTS.md`
INV-20). `CLI.md` (`catalyst init`) says what an install writes; this
file is the shape alone.

## Legend

- `...` — this directory accepts **files only**. Used under every
  `templates/`: a new template version is a new file
  (`TEMPLATE-<TYPE>-v2.md`), never a subfolder, and never an edit to an
  existing version.
- `[...]` — this directory accepts **files and folders, at any depth** —
  the artifact type's own choice of sub-organization for its actual
  instances (e.g. rule documents nested by domain).

## The tree

```
/
    .ledger/                    # deployment ledger — unaffected by INV-20
    CODE-OF-CONDUCT.md
    DEPLOYMENT.md
    README.md
    version.txt
    rules/
        templates/
            README.md
            templates-rule.md            # templates catalog: Version | File | Timestamp | Notes
            TEMPLATE-RULE-v1.md
            ...
        domains/                         # nested here — domains exist only to group rules
            templates/
                README.md
                templates-domain.md
                TEMPLATE-DOMAIN-v1.md
                ...
            README.md
            domains.md                   # domains catalog
            [...]
        README.md
        Rules-of-Rules.md
        rules.md                         # rules catalog
        [...]                            # actual rule documents, typically nested by domain
    <folder>/                            # one per active-module entity type (its ETD's storage folder)
        templates/
            README.md
            templates-<entity-type>.md
            TEMPLATE-<ENTITY-TYPE>-v1.md
            ...
        README.md
        <folder>.md                      # <entity-type> catalog
        [...]
    reconciliations/
        templates/
            README.md
            templates-reconciliation.md
            TEMPLATE-RECONCILIATION-v1.md
            ...
        README.md
        reconciliations.md            # reconciliations catalog
        [...]
    workflows/
        templates/
            README.md
            templates-workflow.md
            TEMPLATE-WORKFLOW-v1.md
            ...
        README.md
        workflows.md                  # workflows catalog
        [...]
    IAM/
        identity.json                    # the pointer to the deployment's catalyst-users configuration
        signers.jsonl                    # the signers ledger: one line per identity that has signed, append-only
        users/                           # no registry: people are catalyst-users'
            templates/
                README.md
                templates-user.md        # templates catalog: Version | File | Timestamp | Notes
                TEMPLATE-USERS-v1.json   # how users are shown: display only, no person, no grant
                ...
            README.md
        roles/                           # no registry: roles and their grants are catalyst-users'
            templates/
                README.md
                templates-role.md
                TEMPLATE-ROLES-v1.json   # the roles' names and how they are shown; grants nothing
                ...
            README.md
        groups/
            templates/
                README.md
                templates-group.md
                TEMPLATE-GROUPS-v1.json  # how groups are shown
                ...
            README.md
    modules/                             # Process Modules & ETD schemas (MODULE-SPECIFICATION.md)
        <module-id>/
            module.yaml                  # Module manifest
            schemas/                     # ETD schema definitions (.yaml)
            templates/                   # Document markdown templates
            commands/                    # Module slash commands (.md)
            skills/                      # Agent skills exported by module
    development/
        <folder>/                        # active-module entity types whose ETD stores them under development/
            templates/ ...               # same shape as a top-level <folder>/
            README.md
            <folder>.md
            [...]
        README.md
        journal/                         # not an artifact type (INV-17): <actor>@<machine>/<YYYY-MM>.jsonl shards
```

Which `<folder>/` directories exist, and whether each sits at the top
level or under `development/`, is decided by the active process module's
Entity Type Definitions (`MODULE-SPECIFICATION.md` §4); every one of them
follows the same INV-20 shape. A module may also deploy generated,
non-artifact files of its own (see its `INVARIANTS.module.md`).

Work items (epics, stories, tasks) are not part of this core tree: a
module declares them as its own types when its process needs them
(ADR-022).

## Exceptions to the pattern

A handful of files are deliberately **not** artifact types and so carry
no `templates/` of their own, even though they sit inside a directory
that has one:

- Any generated summary file the active module deploys (its
  `INVARIANTS.module.md` names them) — machine-regenerated, never
  hand-edited, never versioned as a template.
- `development/journal/` (INV-17) — an append-only log in shards (and,
  before kernel 0.50, `development/journal.jsonl`), not a document type
  with versions.
- `rules/Rules-of-Rules.md` — the document that *governs* an artifact
  type, sibling to its `templates/` and instance catalog, not an
  instance itself.

## See also

- [`CLI.md`](CLI.md) `catalyst init` — what builds this tree;
  [`INSTANTIATION-GUIDE.md`](INSTANTIATION-GUIDE.md) §1 — the judgment
  around it.
- [`INSTANTIATION-CHECKLIST.md`](INSTANTIATION-CHECKLIST.md) — the
  tickable version of the same steps.
- [`rules-of-rules.template.md`](rules-of-rules.template.md) §15 — the
  rule this layout satisfies.
- [`migrations/`](migrations/) — how an existing deployment built under
  an older layout gets here.

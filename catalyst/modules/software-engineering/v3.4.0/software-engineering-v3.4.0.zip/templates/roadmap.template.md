# `RM-NNNNNN` roadmap — template

> Copy this file to `development/roadmaps/templates/TEMPLATE-ROADMAP-v1.md`
> on first deploy (see `INSTANTIATION-GUIDE.md` and `INVARIANTS.module.md`
> INV-SE-3 and `INVARIANTS.md` INV-20), the same way every other `TEMPLATE-<TYPE>-vN.md` seeds
> its type. `/roadmap-add
> <name> <file>` then copies *this* template to
> `development/roadmaps/<name>.md` each time a new named roadmap is
> ingested — one file per named roadmap, registered in
> `development/roadmaps/roadmaps.md`.
>
> Unlike the other artifact templates, a roadmap file is not filled in
> once by a human: `/roadmap-add`/`/roadmap-update`/`/roadmap-merge` add
> or update its `RM-NNNNNN` rows from an external source file, and
> `/show-backlog` refreshes each row's `Status`/`Linked` columns from
> every `FEAT-`/`REQ-` currently linked to it — `Linked` is a
> comma-separated list, not a single ID (`Rules-of-Rules.md` rr-SE-003: a
> roadmap item of real size is expected to decompose into more than one
> requirement). Hand-edit the `Notes` column freely; never hand-edit
> `Status` or `Linked` — the next `/show-backlog` run overwrites them
> from the real indexes, the same way it overwrites
> `development/BACKLOG.md` (INV-SE-2).

**Name:** {{name — the identifier used in `/roadmap-add`/`-remove`/`-update`/`-merge`, and this file's own filename}}
**Source:** {{the file path last ingested via `/roadmap-add` or `/roadmap-update` — `/roadmap-merge` does not change this}}
**Added:** {{DATE}}
**Last updated:** {{DATE}}
**Retired:** {{DATE, only present if `/roadmap-remove` retired this roadmap instead of deleting it because one or more of its items are still linked — omit this field entirely otherwise}}

## Items

| ID | Title | Description | Status | Linked | Start | Due | Signed-off-by | Notes |
|---|---|---|---|---|---|---|---|---|
| `RM-000001-Ab3xR9pQ` (userid suffix = the ingesting user's, `Rules-of-Rules.md` §20) | {{short title, as given by the source file}} | {{a sentence or two summarizing the item, from the source file — not a restatement of Title}} | Not triaged | *(none)* | {{YYYY-MM-DD or empty}} | {{YYYY-MM-DD or empty}} | {{registered user who ran the ingest — see `CODE-OF-CONDUCT.md` §2}} | {{free text}} |

## Status values

- **Not triaged** — ingested; no `FEAT-`/`REQ-` for it yet (`Linked` empty).
- **Triaged** — a `FEAT-NNNNNN` exists for this item (see its `Roadmap` field); `Linked` names only that `FEAT-`.
- **In progress** — at least one `REQ-NNNNNN` is linked and at least one of them isn't yet in a closed state (`Completed`/`Abandoned`).
- **Done** — **every** linked `REQ-NNNNNN` is in a closed state (`Completed`/`Abandoned`).

These four are the roadmap ETD's `allowed_values`, exactly as spelled; `Done` is its only closed state.

## How this file is maintained

- `/roadmap-add <name> <file>` creates this file (this template, once)
  and parses `<file>` into one `RM-NNNNNN` row per distinct item it
  identifies (`Not triaged`, globally next ID across every named
  roadmap — never reused, same as `FEAT-NNNNNN`), `Signed-off-by` set per
  `CODE-OF-CONDUCT.md` §2.
- `/roadmap-update <name> <file>` re-reads `<file>` as the new full,
  authoritative version of this roadmap: adds rows for new items,
  updates matched rows' `Title`/`Description`/`Notes` (matched by
  title/description similarity — ask the user rather than guessing when
  ambiguous), and flags in `Notes` (never deletes) any row whose item no
  longer appears in the new file. Updates `Source`/`Last updated` above.
- `/roadmap-merge <name> <update file>` treats `<update file>` as a
  partial delta, not the full roadmap: only adds/updates the rows it
  actually contains, with the same matching rule as `-update`. Does not
  compare against or flag rows the delta doesn't mention, and does not
  change `Source` — only `Last updated`.
- `/roadmap-remove <name>` deletes this file and its `roadmaps.md` entry
  outright **only if no row's `Linked` field is set**. If any row is
  linked to a `FEAT-`/`REQ-`, deleting would break that cross-reference
  (`Rules-of-Rules.md` §4's "never delete, retire in place" principle
  applies here too) — instead it adds the `Retired` field above, marks
  this roadmap `retired` in `roadmaps.md`, and leaves every row and ID
  exactly as they are, resolvable, just excluded from `/show-backlog`'s
  active Roadmap section going forward.
- A row stays `Not triaged` until a human decides it's worth tracking
  inside catalyst, at which point `/create-feature` opens its `FEAT-NNNNNN`
  (citing this row's `RM-NNNNNN` ID in the feature's own `Roadmap` field).
- From there, the normal `FEAT-` → `REQ-` promotion applies
  (`Rules-of-Rules.md` rr-SE-001/002/003, `INVARIANTS.module.md` INV-SE-1) — one or more
  times, once per requirement the item decomposes into; this file's
  `Status`/`Linked` columns always mirror every artifact currently linked,
  refreshed by `/show-backlog` — never edited here directly.
